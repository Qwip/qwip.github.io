daedalus-ips
============

daedalus Indoor Positioning System

http://www.daedalus.ei.tum.de

Abhängigkeiten:
python3-gi python3-gi-cairo python3-all python3-regex python3-serial python3-gobject

Zum Starten run.sh ausführen.
